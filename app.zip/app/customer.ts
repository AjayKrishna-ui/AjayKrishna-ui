export class Customer{
    id!:number;
    name!:String;
    email!:String;
    address!:String;
    phone!:String;
    password!:String;
  /*  constructor(){
        this.id;
        this.name;
        this.email;
        th
   }*/
}
