import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  

  private basePath = 'http://localhost:8090/rest/customer';

  constructor(private http: HttpClient) { }


  createCustomer(customer: Customer): Observable<any> {
    return this.http.post(`${this.basePath}/save`, customer, {responseType: 'text'});
  }


}
