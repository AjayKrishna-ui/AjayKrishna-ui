import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../customer.service';
import { Customer } from '../customer';

@Component({ 
  selector: 'register-root',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  // form backing object
  customer!: Customer;
  // message to ui
  message!: String;

  // inject service class
  constructor(private service:  CustomerService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.customer = new Customer();
  }

  // tslint:disable-next-line: typedef
  createCustomer() {
    this.service.createCustomer(this.customer)
    .subscribe(data => {
      this.message = data; // read message
      this.customer = new Customer(); // clear form
    }, error => {
      console.log(error);
    });
  }

}