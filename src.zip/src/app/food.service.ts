import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Food } from './food';


@Injectable({
  providedIn: 'root'
})
export class FoodService {

  private basePath = 'http://localhost:8090/rest/Food';

  constructor(private http: HttpClient) { }


  getAllFood(): Observable<Food[]> {
    return this.http.get<Food[]>(`${this.basePath}/all`);
  }

  deleteOneFood(food_id: number): Observable<any> {
    return this.http.delete(`${this.basePath}/remove/${food_id}`, {responseType: 'text'});
  }

  createFood(food: Food): Observable<any> {
    return this.http.post(`${this.basePath}/save`, food, {responseType: 'text'});
  }

  getOneFood(food_id:number): Observable<Food> {
    return this.http.get<Food>(`${this.basePath}/one/${food_id}`);
  }

 

}
