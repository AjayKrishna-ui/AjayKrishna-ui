import { Component, OnInit } from '@angular/core';
import { Food } from '../food';
import { FoodService} from './../food.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  food: Food;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: FoodService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.food = new Food();
  }

  // tslint:disable-next-line: typedef
  createFood(id:number,p:string,cost:number) {
    this.food.food_price=cost;
    this.food.food_name=p;
    this.food.food_id=id;
    console.log(this.food.food_price);
    console.log(this.food.food_name);
        this.service.createFood(this.food)
    .subscribe(data => {
      this.message = data; // read message
      this.food = new Food(); // clear form

    }, error => {
      console.log(error);
    });
  }

}

