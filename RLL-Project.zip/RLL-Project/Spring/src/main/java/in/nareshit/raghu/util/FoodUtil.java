package in.nareshit.raghu.util;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Food;
import in.nareshit.raghu.model.Student;
@Component
public class FoodUtil {
	public void mapToActualObject(Food actual, Food food) {
		
			actual.setFood_name(food.getFood_name());
		actual.setFood_id(food.getFood_id());
		actual.setFood_price(food.getFood_price());
	
	}

}
