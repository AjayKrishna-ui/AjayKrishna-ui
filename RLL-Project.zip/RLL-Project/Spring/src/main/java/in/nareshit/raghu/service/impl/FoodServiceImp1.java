package in.nareshit.raghu.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Food;
import in.nareshit.raghu.repo.FoodRepository;
import in.nareshit.raghu.service.IFoodService;
@Service
public class FoodServiceImp1 implements IFoodService{
	@Autowired
	private FoodRepository repo;
	
	@Override
	public Integer saveFood(Food f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateFood(Food f) {
		repo.save(f);
	}

	
	@Override
	public void deleteFood(Integer food_id) {
		repo.deleteById(food_id);
	}

	@Override
	public Optional<Food> getOneFood(Integer food_id) {
		return repo.findById(food_id);
	}

	@Override
	public List<Food> getAllFood() {
		return repo.findAll();
	}


	@Override
	public boolean isFoodExist(Integer food_id) {
		return repo.existsById(food_id);
	}
}
