//import { StudentEditComponent } from './Login/login.component';
import { StudentCreateComponent } from './student-create/student-create.component';
//import { StudentAllComponent } from './student-all/student-all.component';
import { LoginComponent } from './Login/login.component';
import { MenuComponent } from './menu/menu.component';
import { OrdersComponent } from './orders/orders.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ContactComponent } from './contact/contact.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path: 'all', component:LoginComponent},
  {path: 'add', component: StudentCreateComponent},
  {path: 'Menu', component: MenuComponent},
  {path: 'Order', component:OrdersComponent },
  {path: 'Feedback', component:FeedbackComponent },
  {path: 'Contact', component:ContactComponent }
 // {path: 'edit/:id', component: StudentEditComponent},
  //{path: '', redirectTo: 'all', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
