export class LoginVariable {
    regid: number;
    password: String;
}
