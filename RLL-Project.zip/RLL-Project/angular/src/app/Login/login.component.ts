import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import {  Router } from '@angular/router';
import { Student } from '../student';
import { LoginVariable } from '../loginvariable';

@Component({
  selector: 'app-root',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // declare variables
   variable:LoginVariable;
   student: Student;
  regid:number;

  // inject service and acivated Route param
  constructor(private service: StudentService, private router: Router) { }

  ngOnInit(): void {
    // read id sent by all component as /edit/id
    // tslint:disable-next-line: no-string-literal
    this.variable=new LoginVariable();}
    newUser()
    {
      this.router.navigate(['/add']);
  
    }
    // make service call to get student object
    Login(){
    this.service.getOneStudent(this.variable.regid).subscribe(
      data => {
      this.student = data;
      this.check();
      console.log(this.student);
    }, error => {
      console.log(error);
    });
  }
  check()
    {
      if (this.variable.regid ==this.student.regid && this.variable.password==this.student.password) 
      {
        console.log('11');
      this.router.navigate(['/Menu']);

    }
    else
    {
      console.log('red');

      alert('Incorrect Login Details');
     
    }
    }

}
