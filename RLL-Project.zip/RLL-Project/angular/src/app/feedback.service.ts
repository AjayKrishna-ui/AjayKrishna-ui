import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feedback } from './feedback';


@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  private basePath = 'http://localhost:8090/rest/Feedback';

  constructor(private http: HttpClient) { }


 
  createFeedback(feedback: Feedback): Observable<any> {
    return this.http.post(`${this.basePath}/save`, feedback, {responseType: 'text'});
  }

 

}