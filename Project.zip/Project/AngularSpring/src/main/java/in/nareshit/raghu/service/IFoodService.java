package in.nareshit.raghu.service;
import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Food;


public interface IFoodService {
    Integer saveFood(Food f);
	
	void updateFood(Food f);
	
	

	Optional<Food> getOneFood(Integer food_id);
	List<Food> getAllFood();

	void deleteFood(Integer food_id);
	
	boolean isFoodExist(Integer food_id);
}
